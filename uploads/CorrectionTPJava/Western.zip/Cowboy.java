public class Cowboy extends Humain implements VisagePale {
    private int popularité;
    protected String adjectif;

    public Cowboy(String name) {
        super(name);
        popularité = 0;
        adjectif = "vaillant";
        setBoisson("whisky");
    }

    public void presentation() // surcharge de la méthode presentation de la classse mère
    {
        super.presentation();
        parle("Tout le farwest dit que je suis " + adjectif + ".");
    }

    public void tire(HorsLaLoi mechant) {
        System.out.println("Le " + adjectif + " " +
                quelEstTonNom() + " tire sur "
                + mechant.quelEstTonNom() + ". PAN !");
        parle("Prend cela crapule !");
    }

    public void recherche(HorsLaLoi b) {}

    public void libere(Dame captive) {
        parle("Je vous libère noble " + captive.quelEstTonNom() + ".");
        popularité++;
        captive.estLiberee(this);
    }

    public void scalp() {
        parle("Aie ma tête !");
    }
}
