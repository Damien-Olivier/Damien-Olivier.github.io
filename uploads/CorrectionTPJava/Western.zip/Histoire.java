public class Histoire {
    public static void main(String[] args) throws Exception {
        System.out.println("A l'ouest du Havre");
        Humain adam = new Humain("Adam");
        Humain eve = new Humain("Eve");
        Dame lucie = new Dame("Lucie");
        Brigand joeDalton = new Brigand("Joe");
        Cowboy lukyLuke = new Cowboy("Luke");
        Barman tenancier =  new Barman("Tenancier", "Bar-omètre");
        Cowboy clint   = new Sherif("Clint");
        Sherif etoileDor = new Sherif("Étoile d'or");
        HorsLaLoi averel = new Brigand("Averel");
        Ripoux bill = new Ripoux("Bill le crado");
        FemmeBrigand maDalton = new FemmeBrigand("Ma Dalton");
        Dame marie = new Dame("Marie");
        Indien crazyHorse = new Indien("Crazy", "Horse");

        adam.presentation();
        eve.presentation();
        lucie.presentation();
        lucie.changeRobe("rouge");
        joeDalton.presentation();
        lukyLuke.presentation();
        joeDalton.kidnappe(lucie);
        lukyLuke.tire(joeDalton);
        lukyLuke.libere(lucie);
        tenancier.presentation();
        tenancier.sert(lucie);
        clint.presentation();
        clint.recherche(joeDalton);
        clint.tire(joeDalton);
        joeDalton.emprisonne(clint);
        averel.getMiseAPrix();
        etoileDor.presentation();
        etoileDor.tire(averel);
        etoileDor.recherche(averel);
        etoileDor.coffre(averel);
        etoileDor.presentation();
        bill.presentation();
        bill.kidnappe(lucie);
        maDalton.presentation();
        maDalton.kidnappe(marie);
        bill.recherche(maDalton);
        crazyHorse.presentation();
        crazyHorse.scalper(joeDalton);
    }
}
