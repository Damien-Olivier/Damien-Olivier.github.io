public interface VisagePale {
    void scalp();
    String quelEstTonNom();
}
