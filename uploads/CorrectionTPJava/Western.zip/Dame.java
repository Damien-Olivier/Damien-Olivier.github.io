public class Dame extends Humain implements VisagePale {
    private String couleurRobe;
    private boolean enlevee;

    public Dame(String name) {
        super(name);
        couleurRobe = "blanche";
        enlevee = false;
        setBoisson("lait");
    }

    public String quelEstTonNom() {
        return "Miss " + super.quelEstTonNom();
    }

    public void changeRobe(String couleur) {
        couleurRobe = couleur;
        parle("Regardez ma belle robe " + couleurRobe + " ! ");
    }

    public void presentation() {
        parle("J'ai une belle robe " + couleurRobe + ". ");
        super.presentation();
    }

    public void estKidnapee() {
        enlevee = true;
        parle("AAAHHHHH le vil !");
    }

    public void estLiberee(Cowboy luke) {
        enlevee = false;
        parle("Oh mon héro ! " + luke.quelEstTonNom() + ", je vous serai éternellement reconnaissante !");
    }

    public void scalp() {
        parle("Aie ma tête !");
    }

}
