public class Brigand extends Humain implements HorsLaLoi, VisagePale {
    private String look;
    private int nbDamesEnlevees;
    private int miseAPrix;
    private boolean enPrison;
    
    public Brigand(String name) {
        super(name);
        miseAPrix = 100;    // Par défaut
        look = "méchant";
        nbDamesEnlevees = 0;
        enPrison = false;
        setBoisson("tord-boyaux");
    }
    
    public void presentation(){
        super.presentation();
        parle("J'ai l'air " + look + " et j'ai déjà kidnappé " + nbDamesEnlevees + 
              ((nbDamesEnlevees > 1)? " dames." : " dame."));
        parle("Ma tête est mise à prix " + miseAPrix + "$ !! ");      
    }

    public int getMiseAPrix() {
        return miseAPrix;
    }

    public void kidnappe(Dame d) {
        nbDamesEnlevees ++;
        parle("Ah ah ! " + d.quelEstTonNom() + ", tu es mienne désormais !");
    }

    public void emprisonne(Cowboy clint) {
        enPrison = true;
        parle("Damned je suis fait ! " + clint.quelEstTonNom() + ", tu m'as eu !");
    }

    public String quelEstTonNom() {
        return super.quelEstTonNom() + " le " + look + ".";
    }

    public void scalp() {
        parle("Aie ma tête !");
    }
}
