public interface HorsLaLoi {
    public void emprisonne(Cowboy c);
    public void kidnappe(Dame dame);
    public int getMiseAPrix();
    public String quelEstTonNom();
}
