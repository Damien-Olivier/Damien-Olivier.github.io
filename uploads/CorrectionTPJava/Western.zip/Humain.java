public class Humain {
    private String nom;
    private String boissonFavorite;

    public Humain(String name) {
        nom = name;
        boissonFavorite = "eau";
    }

    public void setBoisson(String glouglou) {
        boissonFavorite = glouglou;
    }

    public String quelEstTonNom() {
        return nom;
    }

    public String queBoisTu() {
        return boissonFavorite;
    }

    public void parle(String blabla) {
        System.out.println("(" + nom + ") - " + blabla);
    }

    public void boit() {
        parle("Ah! un bon verre de " + boissonFavorite + " !");
        parle("GLOUPS");
    }

    public void presentation() {
        parle("Bonjour. Je suis " + quelEstTonNom() + " et j'aime le " + queBoisTu() + ".");
    }
}
