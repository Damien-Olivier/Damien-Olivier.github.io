public class Sherif extends Cowboy {
    private int mechantsCoffres;

    Sherif(String nom) {
        super(nom);
        adjectif = "honnête";
        mechantsCoffres = 0;
    }

    public void presentation() {
        super.presentation();
        parle("J'ai déjà coffré " + mechantsCoffres + " brigands.");
    }

    public void coffre(HorsLaLoi mechant) {
        parle("Au nom de loi, je vous arrête, " + mechant.quelEstTonNom() + " !");
        mechant.emprisonne(this);
        mechantsCoffres++;
    }

    public String quelEstTonNom() {
        return "Shérif " + super.quelEstTonNom();
    }

    public void recherche(HorsLaLoi mechant) {
        System.out
                .println("Le shérif " + super.quelEstTonNom() + " se mis à placarder une affiche dans toute la ville !");
        parle("OYEZ OYEZ BRAVE GENS !! " + mechant.getMiseAPrix() + "$ à qui arrêtera " +
                mechant.quelEstTonNom() + " le brigand mort ou vif !!");
    }

}
