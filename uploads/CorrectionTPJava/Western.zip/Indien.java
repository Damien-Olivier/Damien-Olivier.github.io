public class Indien extends Humain {
    private int nombreDePlumes;
    private String totem;

    public Indien(String n, String t) {
        super(n);
        totem = t;
        nombreDePlumes = 1;
        setBoisson("Jus de racine");
    }

    public Indien(String n) {
       this(n, "Coyote"); 
    }

    public void scalper(VisagePale victime) {
        parle(victime.quelEstTonNom() + " Ton heure est venue.");
        victime.scalp();
        nombreDePlumes++;
    }

    public void parle(String blabla) {
        System.out.println("(" + quelEstTonNom() + ") - " + blabla + " Ugh !" );
    }

    public void presentation() {
        super.presentation();
        parle("J'ai " + nombreDePlumes + " plume(s) sur la tête et mon totem est " + totem + ".");
    }
}
