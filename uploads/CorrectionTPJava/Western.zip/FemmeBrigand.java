public class FemmeBrigand extends Dame implements HorsLaLoi {
    private int miseAPrix = 50;

    public FemmeBrigand(String nom) {
        super(nom);
        setBoisson("Cognac");
    }

    public void emprisonne(Cowboy c) {
        parle("Ouh la la, je suis faite" + c.quelEstTonNom() + ", tu m'as eu !");
    }

    public void kidnappe(Dame lady) {
        System.out.println("Ciel ! " + quelEstTonNom() + " a enelevé " + lady.quelEstTonNom() + " !!");
        parle("AHah ! " + lady.quelEstTonNom() + ", fini la rigolade, par ici la rançon.");
        lady.estKidnapee();
        miseAPrix += 300;
    }

    public int getMiseAPrix() {
        return miseAPrix;
    }

    // La méthode quelEstTonNom est définie grace à l'héritage
}
