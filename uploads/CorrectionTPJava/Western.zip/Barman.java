public class Barman extends Humain {
    private String bar;

    public Barman(String name, String nomDuBar) {
        super(name);
        bar = nomDuBar;
        setBoisson("vin");
    }

    public Barman(String name) {
        this(name, "Chez " + name); // Appel au constructuer avec 2 paramètres
    }

    public void sert(Humain h) {
        parle("Tiens " + h.quelEstTonNom() + ", voila un godet de " + h.queBoisTu() + "." );
        h.boit();
    }

    public void presentation() {
        super.presentation();
        parle("Je suis le barman du " + bar + ".");
    }

    public void parle(String blabla) {
        System.out.println("(" + quelEstTonNom() + ") - " + blabla + " Coco.");
    }
    
}
