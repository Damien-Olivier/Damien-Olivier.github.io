public class Ripoux extends Sherif implements HorsLaLoi {
    private boolean enPrison;
    private int miseAPrix;

    Ripoux(String nom) {
        super(nom);
        enPrison = false;
        miseAPrix = 0;
    }

    public void emprisonne(Cowboy c)
    {
        enPrison = true;
        parle("Damned je suis fait ! " + c.quelEstTonNom() + ", tu m'as eu !");
    }

    public void kidnappe(Dame dame){
        System.out.println("Oh my God " + quelEstTonNom() + " a enlevé " + dame.quelEstTonNom());
        parle("Ahah ! " + dame.quelEstTonNom() + ", tu es mienne maintenant !");
        dame.estKidnapee();
        miseAPrix += 200;
    }
    
    public int getMiseAPrix() {
        return miseAPrix;
    }

    public String quelEstTonNom() {
        return super.quelEstTonNom();
    }
    
}
