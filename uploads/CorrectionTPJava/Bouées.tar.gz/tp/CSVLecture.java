package l2.tp;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

public class CSVLecture {
	private static HashMap<Date, ArrayList<Double>> lesDonnees = new HashMap<>();

	/**
	 * On fait le ménage dans les données :
	 * - absence de valeurs ;
	 * - NaN ;
	 * - données mal transmises?
	 * @param valeurs
	 * @return
	 */
	private static ArrayList<Double> traiteValeurs(String[] valeurs) {
		ArrayList<Double> valeursDouble = new ArrayList<>(valeurs.length);
		for (String v : valeurs) {
			if (v.length() != 0) {
				try {
					Double convert = Double.valueOf(v);
					if (!convert.isNaN())
						valeursDouble.add(convert);
				} catch (NumberFormatException e) {
				}
			}
		}
		return valeursDouble;
	}

	/**
	 * Traitement d'une ligne de mesure
	 * 
	 * @param l ligne de mesure pour une date donnée
	 */
	private static void traiteLigne(String l) {
		String[] elements = l.split(",");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		try {
			Date dateMesure = sdf.parse(elements[0]);
			if (!lesDonnees.containsKey(dateMesure)) {
				lesDonnees.put(dateMesure, traiteValeurs(Arrays.copyOfRange(elements, 1, elements.length)));
			} else
				lesDonnees.get(dateMesure).addAll(traiteValeurs(Arrays.copyOfRange(elements, 1, elements.length)));

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Lit des mesures contenues dans un fichier csv
	 * 
	 * @param nomf nom du fichier de mesure
	 */
	public static void lectureFromCSV(String nomf) {
		Path pathToFile = Path.of(nomf);
		try (BufferedReader br = Files.newBufferedReader(pathToFile)) {
			String ligne;

			while ((ligne = br.readLine()) != null)
				traiteLigne(ligne);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static HashMap<Date, ArrayList<Double>> getDonnees() {
		return lesDonnees;
	}

	public static void main(String[] s) {
		lectureFromCSV("mesures.csv");
	}
}