package l2.tp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import l2.tp.util.ListeFichiers;

public class MainBouees {


	public static void main(String[] args) throws ParseException {
		TraiteDonnees exp1 = new TraiteDonnees("Data","mesures.csv");
		exp1.afficheDonnees();
		Date maDate = new SimpleDateFormat("dd/MM/yy").parse("02/02/19");
		System.out.println("Moyenne du " + maDate + " = " + exp1.moyenneJour(maDate));
		System.out.println("Moyenne globale           = " + exp1.moyenneGlobale());
		Date debut = new SimpleDateFormat("dd/MM/yy").parse("20/11/18");
		Date fin = new SimpleDateFormat("dd/MM/yy").parse("25/11/18");
		System.out.println("Moyenne entre " + debut + " et " + fin + " = " + exp1.moyenneEntre(debut, fin));
		exp1.ecrireFichierTraitement("Traitement");
		ArrayList<String> lf = ListeFichiers.listeEnsFichiers("Data", "*mesure*.{csv,CSV}");
		for(String nf : lf) {
			 String[] s = nf.toString().split("/");
			 TraiteDonnees exp = new TraiteDonnees("Data",s[s.length - 1]);
			 exp.ecrireFichierTraitement("Traitement");
		} 
	}

}
