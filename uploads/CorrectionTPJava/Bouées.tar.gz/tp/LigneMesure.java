package l2.tp;

import java.util.ArrayList;
import java.util.Date;

public class LigneMesure {
	Date date;
	ArrayList<String> donnees;
	public LigneMesure(Date parse, ArrayList<String> arrayList) {
		date = parse;
		donnees = arrayList;
		System.out.println("@@@"+donnees+"@@@@@");
	}

}
