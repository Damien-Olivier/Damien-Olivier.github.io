package l2.tp;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * Cette classe effectue le traitement des données contenues dans un fichier csv. Elle les stocke dans un dictionnaire comportant la date et les valeurs.
 * @author damien
 */
public class TraiteDonnees {
	/**
	 * Classe interne. Les objets CumulJour servent à stocker la somme de toutes les valeurs et le nombre de valeurs. 
	 */
	private class CumulJour {
		private Date jour;
		private double cumul = 0;
		private int nbValeur = 0;
	}

	private String nomf;
	private HashMap<Date, ArrayList<Double>> lesDonnees;

	/**
	 * Lecture des donnéees dans un fichier.
	 * @param ou le répertoire
	 * @param s  le nom du fichier
	 */
	public TraiteDonnees(String ou, String s) {
		nomf = s;
		CSVLecture.lectureFromCSV(ou+'/'+nomf);
		lesDonnees = CSVLecture.getDonnees();
	}

	void afficheDonnees() {
		for (Map.Entry<Date, ArrayList<Double>> data : lesDonnees.entrySet()) {
			System.out.println("Date : " + data.getKey() + " : " + data.getValue());
			System.out.println("---------------------------");
		}
	}

	/**
	 * Effectue la somme des valeurs pour une date donnée.
	 * @param d la clef dans la collection
	 * @return la somme et le nombre de valeurs sous la forme d'un objet CumulJour.
	 */
	public CumulJour cumulJ(Date d) {
		CumulJour m = new CumulJour();
		m.jour = d;
		ArrayList<Double> valeurs = lesDonnees.get(m.jour);
		m.nbValeur = valeurs.size();
		for (Double v : valeurs)
			m.cumul += v;
		return m;
	}

	public double moyenneJour(Date d) {
		CumulJour c = cumulJ(d);
		return c.cumul / c.nbValeur;
	}


	public double moyenneGlobale() {
		CumulJour m;
		int nbValeur = 0;
		double cumul = 0;
		
		for (Date clef : lesDonnees.keySet()) {
			m = cumulJ(clef);
			nbValeur += m.nbValeur;
			cumul += m.cumul;
		}
		return cumul / nbValeur;
	}

		

	public double moyenneEntre(Date debut, Date fin) {
		int nbValeur = 0;
		double cumul = 0;
		CumulJour m;

		for (Map.Entry<Date, ArrayList<Double>> data : lesDonnees.entrySet()) {
			Date d = data.getKey();
			if (d.compareTo(debut) >= 0 && d.compareTo(fin) <= 0) {
				m = cumulJ(data.getKey());
				nbValeur += m.nbValeur;
				cumul += m.cumul;
			}
		}
		return cumul / nbValeur;
	}
	
	/**
	 * Ecrit dans un fichier pour chacune des dates la moyenne.
	 * On précise dans quel répertoire sera le fichier de traitement. On ajoute "Moyenne" au nom du fichier traité.
	 * @param ou répertoire ou s'effectue l'éciture du fichier
	 */
	public void ecrireFichierTraitement(String ou) {
		CumulJour m = null;
		Path pathToFile = Path.of(ou+"/Moyenne"+nomf);
		try (BufferedWriter bw = Files.newBufferedWriter(pathToFile)){
			Date d = null;
			Set<Entry<Date, ArrayList<Double>>> ensemble = lesDonnees.entrySet();
			Iterator<Entry<Date, ArrayList<Double>>> it = ensemble.iterator();
			while(it.hasNext()){
				Map.Entry<Date, ArrayList<Double>> data = it.next(); 
				d = data.getKey();
				m = cumulJ(d);
				bw.write(d.toString() + ',' + m.cumul/m.nbValeur + '\n');
			}
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}	
	}
}