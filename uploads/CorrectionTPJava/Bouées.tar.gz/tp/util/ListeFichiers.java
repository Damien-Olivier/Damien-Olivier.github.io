package l2.tp.util;

import java.io.IOException;
import java.nio.file.DirectoryIteratorException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ListeFichiers {

	public static ArrayList<String> listeEnsFichiers(String repertoire, String filtre) {
		ArrayList<String> listeFichiers = new ArrayList<>();
		try (DirectoryStream<Path> streamNom = Files.newDirectoryStream(Paths.get(repertoire), filtre)) {
			for (Path fichier : streamNom) {
				if (!Files.isDirectory(fichier))
					listeFichiers.add(fichier.toAbsolutePath().normalize().toString());
			}
		} catch (IOException | DirectoryIteratorException ex) {
			System.err.println(ex);
		}
		return listeFichiers;
	}
	
	
	public static ArrayList<String> listeEnsFichiers(String repertoire) {
		return listeEnsFichiers(repertoire, "*");
	}
}
