public class IntegrationTrapeze {
    public  static double integre1(double a, double b, int n, FonctionDUneVariable f) {
        double deltaX = (b - a) / n;
        double somme = 0;
        double xi = a, xiPlus1;

        for(int i = 1; i <= n; i++) {
            xiPlus1 = xi + deltaX;
            somme += (xiPlus1 - xi) * (f.calculFonctionEn(xi) + f.calculFonctionEn(xiPlus1))/2;
            xi = xiPlus1;
        }
        return somme;
    }

    public static double integre2(double a, double b, int n, FonctionDUneVariable f) throws ArithmeticException{
        double deltaX = (b - a) / n;
        double somme = 0;
        double xi = a;
    
        if (f.estDefinie(a) && f.estDefinie(b))
            somme = (f.calculFonctionEn(a) + f.calculFonctionEn(b)) / 2;
            else throw new ArithmeticException("Fonction non définie");
    
        for(int i = 1; i < n; i++) {
            xi += deltaX;
            if(f.estDefinie(xi))
                somme += f.calculFonctionEn(xi);
                else throw new ArithmeticException("Fonction non définie");
        }
        return somme * deltaX;
       }
}
