public class IntegrationAdaptative extends IntegrationTrapeze {
    static final int NBPASINF = 5;
    static final int NBPASSUP = 20;
    static final double ERREUR = 1E-6;

    public static double integreAdap(double a, double b, FonctionDUneVariable f)
    {
        double resultat = integre2(a, b, NBPASINF, f);
        if (Math.abs(resultat - integre2(a, b, NBPASSUP, f)) < ERREUR)
            return resultat;
            else return integreAdap(a, (a+b)/2, f) + integreAdap((a+b)/2, b, f);
    }
}
