import java.util.Scanner;

// Pour tester
class Sinus implements FonctionDUneVariable {
    public double calculFonctionEn(double x) {
        return Math.sin(x);
    }

    public boolean estDefinie(double x) {
        return true;
    }
}

class UnSurX implements FonctionDUneVariable {
    final double PETIT = 1E-8;

    public double calculFonctionEn(double x) {
        return 1. / x;
    }

    public boolean estDefinie(double x) {
        return (Math.abs(x) < PETIT ? false : true);
    }
}

class SinXSurX implements FonctionDUneVariable {
    public double calculFonctionEn(double x) {
        return x == 0 ? 1 : Math.sin(x) / x;
    }

    public boolean estDefinie(double x) {
        return true;
    }
}

public class CalculIntegrales {
    public static void main(String[] args) {
        // On vérifie
        Sinus f = new Sinus();
        System.out
                .println("Intégrale de sin(x) entre 0 et Pi/2 : " + IntegrationTrapeze.integre1(0, Math.PI / 2, 50, f));

        UnSurX g = new UnSurX();
        try {
            System.out.println("Intégrale de 1/X entre 0 et 9 : " + IntegrationTrapeze.integre2(0, 9, 10, g));
        } catch (ArithmeticException e) {
            System.err.println("Non intégrable");
        }
        try {
            System.out.println("Intégrale de 1/X entre 1 et 9 : " + IntegrationTrapeze.integre2(1, 9, 10, g));
        } catch (ArithmeticException e) {
            System.err.println("Non intégrable");
        }

        SinXSurX h = new SinXSurX();
        try {
            System.out.println("I1 = " + IntegrationTrapeze.integre2(0, 10*Math.PI, 10, h));
            System.out.println("I2 = " + IntegrationAdaptative.integreAdap(0, 10*Math.PI, h));
        } catch (ArithmeticException e) {
            System.err.println("Non intégrable");
        }
    }
}
