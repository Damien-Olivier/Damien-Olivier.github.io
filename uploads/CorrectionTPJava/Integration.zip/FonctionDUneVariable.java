public interface FonctionDUneVariable {
    /**
     * 
     * @param x
     * @return vai si la fonction est définie en x
     */
    boolean estDefinie(double x);

    /**
     * Calcul d'une fonction en un point
     * @param x abscisse
     * @return f(x)
     */
    double calculFonctionEn(double x);
}
